<?php

$mod_strings['LBL_SYNCINBOUNDEMAILS'] = 'sync InboundEmails To Email Archive Configs';

